#include "szotar_header.h"
#include "hasitotabla_header.h"
using namespace std;
// Futo Evelin, feim2349

int main() {
    
    hashtable szotar;
    beolvas(szotar);
    menu(szotar);
    return 0;
}
